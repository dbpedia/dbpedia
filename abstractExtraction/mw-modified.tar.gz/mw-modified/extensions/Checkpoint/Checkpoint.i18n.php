<?php

$messages = array();

$messages['en'] = array(
	'checkpoint'         => 'Save and continue editing',
	'checkpoint-desc'    => 'Allows one to save an edit and continue editing',
	'checkpoint-tooltip' => 'Save your progress and continue editing the page',
	'checkpoint-notice'  => '([[{{ns:project}}:Checkpoint|checkpoint save]])',
);