<?php
/**
 * Internationalization file for the CategoryTests extension
*/

$messages = array();

/** English
 * @author Ryan Schmidt
*/
$messages['en'] = array(
	'categorytests' => 'Functions for category testing'
);