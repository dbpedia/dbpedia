<?php

/* Kazakh default, fallback to kk-cyrl */
require_once( 'LocalNamesKk-cyrl.php' );
