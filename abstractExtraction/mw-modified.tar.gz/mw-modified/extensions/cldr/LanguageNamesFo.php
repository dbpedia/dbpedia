<?php
$names = array(
'fo' => 'føroyskt',
);
