<?php
$names = array(
'si' => 'සිංහල',
);
