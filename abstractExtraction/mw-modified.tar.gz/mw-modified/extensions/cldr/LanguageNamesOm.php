<?php
$names = array(
'om' => 'Oromoo',
);
