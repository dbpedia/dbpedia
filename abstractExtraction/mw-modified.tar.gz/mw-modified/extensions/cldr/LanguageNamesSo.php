<?php
$names = array(
'fy' => 'Firiisiyan Galbeed',
'so' => 'Soomaali',
);
