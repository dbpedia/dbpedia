<?php
$names = array(
'kk' => 'Қазақ',
);
