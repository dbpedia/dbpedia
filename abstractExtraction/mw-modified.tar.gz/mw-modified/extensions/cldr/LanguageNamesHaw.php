<?php
$names = array(
'haw' => 'ʻōlelo Hawaiʻi',
);
