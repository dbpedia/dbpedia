<?php
$names = array(
'as' => 'as',
'az' => 'azərbaycanca',
'br' => 'Bretonca',
'de' => 'almanca',
'en' => 'ingiliscə',
'es' => 'ispanca',
'fr' => 'fransızca',
'ja' => 'yaponca',
'pt' => 'portuqalca',
'ru' => 'rusca',
'zh' => 'çincə',
);
