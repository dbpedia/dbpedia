<?php
$names = array(
'gu' => 'ગુજરાતી',
);
