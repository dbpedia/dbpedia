<?php
$names = array(
'da' => 'Èdè Ilẹ̀ Denmark',
'de' => 'Èdè Ilẹ̀ Germany',
'en' => 'Èdè Gẹ̀ẹ́sì',
'fr' => 'Èdè Faransé',
'pl' => 'Èdè Ilẹ̀ Polandi',
'yo' => 'Yorùbá',
);
