<?php
$names = array(
'bar'         => 'Bavarşa',
'bat-smg'  => 'Jemaýtşa',
'bpy'         => 'Bïşnwprïyaşa',
'ext'         => 'Estremadwraşa',
'frc'          => 'Fraswzşa (Kadjwn)',
'frp'         => 'Franswzşa (Provans)',
'hak'        => 'Xakkaşa',
'gan'        => 'Ganşa',
'wuu'       => 'Wuşa',
);
