<?php
$names = array(
'af' => 'Afrikaans',
'de' => 'Duits',
'en' => 'Engels',
'es' => 'Spaans',
'fr' => 'Frans',
'he' => 'Hebreeus',
'it' => 'Italiaans',
'ja' => 'Japannees',
'pt' => 'Portugees',
'ru' => 'Russies',
'zh' => 'Sjinees',
);
