<?php
$names = array(
'ar' => 'Arabisht',
'de' => 'Gjermanisht',
'en' => 'Anglisht',
'es' => 'Spanjisht',
'fr' => 'Frengjisht',
'hi' => 'Hindi',
'it' => 'Italisht',
'ja' => 'Japanisht',
'pt' => 'Portugeze',
'ru' => 'Rusisht',
'sq' => 'shqipe',
'zh' => 'Kineze',
);
