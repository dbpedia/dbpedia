<?php
$names = array(
'uz' => 'Ўзбек',
);
