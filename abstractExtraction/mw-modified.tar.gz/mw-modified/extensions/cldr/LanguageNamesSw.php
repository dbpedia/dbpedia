<?php
$names = array(
'de' => 'kijerumani',
'en' => 'kiingereza',
'es' => 'kihispania',
'fr' => 'kifaransa',
'it' => 'kiitaliano',
'ja' => 'kijapani',
'pt' => 'kireno',
'ru' => 'kirusi',
'sw' => 'Kiswahili',
'zh' => 'kichina',
);
