<?php
$names = array(
'kl' => 'kalaallisut',
);
