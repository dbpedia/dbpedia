<?php
$names = array(
'bn' => 'বাংলা',
);
