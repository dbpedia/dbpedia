<?php
$names = array(
'pa' => 'ਪੰਜਾਬੀ',
);
