<?php
$names = array(
'hy' => 'Հայերէն',
);
