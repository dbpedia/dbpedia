<?php
$names = array(
'de' => 'alemanera',
'en' => 'ingelera',
'es' => 'espainiera',
'eu' => 'euskara',
'fr' => 'frantsesera',
'it' => 'italiera',
'ja' => 'japoniera',
'pt' => 'portugalera',
'ru' => 'errusiera',
'zh' => 'txinera',
);
