<?php
$names = array(
'ar' => 'Arabeg',
'cy' => 'Cymraeg',
'de' => 'Almaeneg',
'en' => 'Saesneg',
'es' => 'Sbaeneg',
'fr' => 'Ffrangeg',
'hi' => 'Hindi',
'it' => 'Eidaleg',
'ja' => 'Siapaneeg',
'pt' => 'Portiwgaleg',
'ru' => 'Rwsieg',
'zh' => 'Tseineeg',
);
