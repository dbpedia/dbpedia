<?php
$names = array(
'gv' => 'Gaelg',
);
