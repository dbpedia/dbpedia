<?php
$names = array(
'kn' => 'ಕನ್ನಡ',
);
