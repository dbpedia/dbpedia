<?php
$names = array(
'ms' => 'Bahasa Melayu',
);
