<?php
$names = array(
'bo' => 'tibetanski',
'de' => 'njemački',
'en' => 'engleski',
'es' => 'španjolski',
'fr' => 'francuski',
'it' => 'talijanski',
'ja' => 'japanski',
'pt' => 'portugalski',
'ru' => 'ruski',
'tk' => 'turkmenski',
'tr' => 'turski',
'und' => 'nepoznati ili nevažeći jezik',
'zh' => 'kineski',
);
