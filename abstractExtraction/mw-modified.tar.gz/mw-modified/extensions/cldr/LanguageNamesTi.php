<?php
$names = array(
'ti' => 'ትግርኛ',
);
