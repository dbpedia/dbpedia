<?php
$names = array(
'af' => 'isiBhunu',
'ar' => 'isi-Alabhu',
'de' => 'isiJalimani',
'en' => 'isiNgisi',
'es' => 'isiSpeyini',
'fr' => 'isiFulentshi',
'hi' => 'isiHindi',
'st' => 'isiSuthu',
'sw' => 'isiSwahili',
'xh' => 'isiXhosa',
'zu' => 'isiZulu',
);
