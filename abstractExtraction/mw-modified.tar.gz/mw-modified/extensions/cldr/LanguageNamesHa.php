<?php
$names = array(
'ha' => 'Haoussa',
);
