<?php
$names = array(
'gl' => 'galego',
);
