<?php
$names = array(
'as' => 'অসমীয়া',
);
