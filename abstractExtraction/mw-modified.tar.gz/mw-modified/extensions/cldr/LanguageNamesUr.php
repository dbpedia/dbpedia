<?php
$names = array(
'ur' => 'اردو',
);
