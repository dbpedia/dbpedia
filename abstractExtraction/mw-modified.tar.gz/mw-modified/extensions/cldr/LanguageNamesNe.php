<?php
$names = array(
'ne' => 'नेपाली',
);
