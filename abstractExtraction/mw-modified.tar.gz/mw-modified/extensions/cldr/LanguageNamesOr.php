<?php
$names = array(
'or' => 'ଓଡ଼ିଆ',
);
