DROP TABLE /*$wgDBprefix*/code_repo;
DROP TABLE /*$wgDBprefix*/code_rev;
DROP TABLE /*$wgDBprefix*/code_authors;
DROP TABLE /*$wgDBprefix*/code_paths;
DROP TABLE /*$wgDBprefix*/code_relations;
DROP TABLE /*$wgDBprefix*/code_tags;
DROP TABLE /*$wgDBprefix*/code_comment;
